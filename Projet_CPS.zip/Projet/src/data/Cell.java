package data;

public enum Cell {
    EMP, PLT, HOL, LAD, HDR, MTL;
}