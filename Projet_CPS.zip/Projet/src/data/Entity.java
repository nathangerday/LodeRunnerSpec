package data;

public interface Entity {

}