package data;

public enum ItemType{
    Treasure;
}