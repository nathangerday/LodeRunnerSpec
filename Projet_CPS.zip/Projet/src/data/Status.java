package data;

public enum Status{
    Playing, Win, Loss;
}