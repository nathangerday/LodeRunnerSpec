package data;

public enum Command{
    NONE, MOVER, MOVEL, MOVEU, MOVED, DIGL, DIGR, USEITEM;
}