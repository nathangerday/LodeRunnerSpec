package data;

public enum GuardType{
    NORMAL;
}