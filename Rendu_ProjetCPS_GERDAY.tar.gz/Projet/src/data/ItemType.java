package data;

public enum ItemType{
    Treasure, Gun, Sword, Flash, Key;
}